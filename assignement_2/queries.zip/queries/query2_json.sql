WITH CharacterSelfies AS (
    SELECT
        cs.CharacterID,
        json_agg(
            json_build_object(
                'SelfieID', cs.SelfieID,
                'ImageURL', cs.ImageURL,
                'CaptureDate', cs.CaptureDate
            )
        ) AS Selfies
    FROM CharacterSelfie cs
    GROUP BY cs.CharacterID
),
CharacterNotifications AS (
    SELECT
        cn.CharacterID,
        json_agg(
            json_build_object(
                'NotificationID', n.NotificationID,
                'Detail', n.Details
            )
        ) AS LatestNotification
    FROM Notification n
    JOIN CharacterNotification cn ON n.NotificationID = cn.NotificationID
    GROUP BY cn.CharacterID
),
CharacterDetails AS (
    SELECT
        c.UserID,
        json_agg(
            json_build_object(
                'CharacterID', c.CharacterID,
                'CharacterInfo', json_build_array(
                    json_build_object(
                        'Name', c.Name,
                        'Realm', c.Realm,
                        'Race', c.Race,
                        'Class', c.Class,
                        'Strength', c.Strength,
                        'Selfies', COALESCE(cs.Selfies, '[]'),
                        'LatestNotification', COALESCE(cn.LatestNotification, json_build_object())
                    )
                )
            )
        ) AS Characters
    FROM Character c
    LEFT JOIN CharacterSelfies cs ON c.CharacterID = cs.CharacterID
    LEFT JOIN CharacterNotifications cn ON c.CharacterID = cn.CharacterID
    GROUP BY c.UserID
),
UserDetails AS (
    SELECT
        ua.UserID,
        ua.Email,
        ua.Age,
        ua.Height,
        ua.Weight,
        COALESCE(cd.Characters, '[]'::json) AS Characters
    FROM UserAccount ua
    LEFT JOIN CharacterDetails cd ON ua.UserID = cd.UserID
)
SELECT json_build_object(
    'UserID', ud.UserID,
    'Email', ud.Email,
    'Age', ud.Age,
    'Height', ud.Height,
    'Weight', ud.Weight,
    'Characters', ud.Characters
) FROM UserDetails ud;
