WITH CharacterInfo AS (
    SELECT
        c.CharacterID,
        c.Name AS CharacterName,
        c.Realm,
        c.Race,
        xmlelement(name "Character",
            xmlattributes(
                c.CharacterID AS "CharacterID",
                c.Name AS "Name",
                c.Realm AS "Realm",
                c.Race AS "Race"
            ),
            xmlelement(name "Selfies",
                (SELECT xmlagg(
                    xmlelement(name "Selfie",
                        xmlattributes(
                            cs.SelfieID AS "SelfieID",
                            cs.ImageURL AS "ImageURL",
                            cs.CaptureDate AS "CaptureDate"
                        )
                    )
                ) FROM CharacterSelfie cs WHERE cs.CharacterID = c.CharacterID)
            ),
            xmlelement(name "Notifications",
                (SELECT xmlagg(
                    xmlelement(name "Notification",
                        xmlattributes(
                            cn.NotificationID AS "NotificationID",
                            n.ExpansionName AS "ExpansionName"
                        ),
                        xmlelement(name "Details", n.Details)
                    )
                ) FROM CharacterNotification cn JOIN Notification n ON cn.NotificationID = n.NotificationID WHERE cn.CharacterID = c.CharacterID)
            ),
            (SELECT xmlelement(name "PaymentMethods",
                xmlagg(
                    xmlelement(name "PaymentMethod",
                        xmlforest(
                            pm.PaymentMethodID AS "PaymentMethodID",
                            pm.Type AS "Type"
                        ),
                        xmlelement(name "Details", pm.Details)
                    )
                )
            ) FROM PaymentMethod pm WHERE pm.UserID = (SELECT UserID FROM Character WHERE CharacterID = c.CharacterID) GROUP BY pm.UserID)
        ) AS CharacterXML
    FROM Character c
),
AggregatedCharacters AS (
    SELECT xmlagg(CharacterXML) AS Characters
    FROM CharacterInfo
)
SELECT xmlelement(name "CharactersRoot", (SELECT Characters FROM AggregatedCharacters)) AS FinalOutput;
