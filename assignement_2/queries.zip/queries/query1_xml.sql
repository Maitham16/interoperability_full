WITH UserSubscriptions AS (
    SELECT
        ua.UserID,
        xmlagg(
            xmlelement(name "Subscription",
                xmlforest(
                    s.SubscriptionID AS "SubscriptionID",
                    s.SubscriptionStartDate AS "StartDate",
                    s.SubscriptionEndDate AS "EndDate",
                    s.SubscriptionAmount AS "Amount"
                )
            )
        ) AS SubscriptionsXML
    FROM UserAccount ua
    JOIN Subscription s ON ua.UserID = s.UserID
    GROUP BY ua.UserID
),
UserPayments AS (
    SELECT
        pm.UserID,
        xmlagg(
            xmlelement(name "PaymentMethod",
                xmlforest(
                    pm.PaymentMethodID AS "PaymentMethodID",
                    pm.Type AS "Type"
                ),
                xmlelement(name "Details",
                    xmlforest(
                        (pm.Details->'card_info'->>'card_number') AS "CardNumber",
                        (pm.Details->'card_info'->>'expiry_date') AS "ExpiryDate"
                    )
                )
            )
        ) AS PaymentsXML
    FROM PaymentMethod pm
    GROUP BY pm.UserID
),
UserCharacters AS (
    SELECT
        c.UserID,
        xmlagg(
            xmlelement(name "Character",
                xmlforest(
                    c.CharacterID AS "CharacterID",
                    c.Name AS "Name",
                    c.Realm AS "Realm",
                    c.Race AS "Race",
                    c.Class AS "Class",
                    c.Strength AS "Strength"
                ),
                (SELECT xmlelement(name "Notifications", xmlagg(n.Details))
                 FROM CharacterNotification cn
                 JOIN Notification n ON cn.NotificationID = n.NotificationID
                 WHERE cn.CharacterID = c.CharacterID)
            )
        ) AS CharactersXML
    FROM Character c
    GROUP BY c.UserID
)
SELECT xmlserialize(DOCUMENT 
    xmlelement(name "Users",
        (SELECT xmlagg(
            xmlelement(name "User",
                xmlattributes(
                    ua.UserID AS "UserID",
                    ua.Email AS "Email",
                    (SELECT COUNT(*) FROM Subscription s WHERE s.UserID = ua.UserID) AS "SubscriptionCount",
                    (SELECT COUNT(*) FROM PaymentMethod pm WHERE pm.UserID = ua.UserID) AS "PaymentMethodCount"
                ),
                (SELECT SubscriptionsXML FROM UserSubscriptions us WHERE us.UserID = ua.UserID),
                (SELECT PaymentsXML FROM UserPayments up WHERE up.UserID = ua.UserID),
                (SELECT CharactersXML FROM UserCharacters uc WHERE uc.UserID = ua.UserID)
            )
        ) FROM UserAccount ua)
    ) AS text);

