WITH UserSubscriptions AS (
    SELECT
        ua.UserID,
        ua.Email,
        json_agg(
            json_build_object(
                'SubscriptionID', s.SubscriptionID,
                'StartDate', s.SubscriptionStartDate,
                'EndDate', s.SubscriptionEndDate,
                'Amount', s.SubscriptionAmount
            )
        ) AS Subscriptions
    FROM useraccount ua
    JOIN Subscription s ON ua.UserID = s.UserID
    GROUP BY ua.UserID
),
UserPayments AS (
    SELECT
        ua.UserID,
        json_agg(
            json_build_object(
                'PaymentMethodID', pm.PaymentMethodID,
                'Type', pm.Type,
                'Details', pm.Details
            )
        ) AS PaymentMethods
    FROM useraccount ua
    JOIN PaymentMethod pm ON ua.UserID = pm.UserID
    GROUP BY ua.UserID
),
UserCharacters AS (
    SELECT
        ua.UserID,
        json_agg(
            json_build_object(
                'CharacterID', c.CharacterID,
                'Name', c.Name,
                'Realm', c.Realm,
                'Race', c.Race,
                'Class', c.Class,
                'Strength', c.Strength,
                'LatestNotification', (
                    SELECT json_build_object(
                        'NotificationID', n.NotificationID,
                        'ExpansionName', (xpath('/notification/expansionName/text()', n.Details))[1]::text,
                        'Detail', (xpath('/notification/detail/text()', n.Details))[1]::text
                    )
                    FROM Notification n
                    JOIN CharacterNotification cn ON n.NotificationID = cn.NotificationID
                    WHERE cn.CharacterID = c.CharacterID
                    ORDER BY n.NotificationID DESC
                    LIMIT 1
                )
            )
        ) AS Characters
    FROM useraccount ua
    JOIN Character c ON ua.UserID = c.UserID
    GROUP BY ua.UserID
)
SELECT json_build_object(
    'UserID', ua.UserID,
    'Email', ua.Email,
    'Subscriptions', us.Subscriptions,
    'PaymentMethods', up.PaymentMethods,
    'Characters', uc.Characters
)
FROM useraccount ua
LEFT JOIN UserSubscriptions us ON ua.UserID = us.UserID
LEFT JOIN UserPayments up ON ua.UserID = up.UserID
LEFT JOIN UserCharacters uc ON ua.UserID = uc.UserID;
