<?php
header('Content-Type: application/json');

function logRequest() {
    $logFile = '/home/alrubayem88/public_html/assignment7/logs/p2_requests_log.txt';
    $data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'],
        'query' => $_SERVER['QUERY_STRING'],
        'body' => file_get_contents('php://input'),
        'headers' => getallheaders()
    ];

    file_put_contents($logFile, json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
}

logRequest();

$inventoryFile = '/home/alrubayem88/public_html/assignment7/data/inventory.json';

function loadInventory() {
    global $inventoryFile;
    $json = file_get_contents($inventoryFile);
    return json_decode($json, true);
}

function saveInventory($inventory) {
    global $inventoryFile;
    file_put_contents($inventoryFile, json_encode($inventory, JSON_PRETTY_PRINT));
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_categories':
        $inventory = loadInventory();
        echo json_encode(array_keys($inventory));
        break;

    case 'get_materials':
        $category = $_GET['category'] ?? '';
        if (empty($category)) {
            http_response_code(400);
            echo json_encode(['error' => 'Category is required']);
            exit;
        }
        $inventory = loadInventory();
        if (!isset($inventory[$category])) {
            echo json_encode(['error' => 'Category not found']);
            exit;
        }
        echo json_encode(array_values($inventory[$category]));
        break;

    case 'get_quantity':
        $category = $_GET['category'] ?? '';
        $itemName = $_GET['item'] ?? '';
        if (empty($category) || empty($itemName)) {
            http_response_code(400);
            echo json_encode(['error' => 'Category and item name are required']);
            exit;
        }
        $inventory = loadInventory();
        if (isset($inventory[$category])) {
            foreach ($inventory[$category] as $item) {
                if ($item['name'] === $itemName) {
                    header('Content-Type: text/plain');
                    echo $item['quantity'];
                    exit;
                }
            }
        }
        http_response_code(404);
        echo json_encode(['error' => 'Item not found']);
        break;

    case 'update_quantity':
        $category = $_GET['category'] ?? '';
        $itemName = $_GET['item'] ?? '';
        $quantity = $_GET['quantity'] ?? '';
        if (empty($category) || empty($itemName) || !is_numeric($quantity)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid input']);
            exit;
        }
        $inventory = loadInventory();
        $found = false;
        foreach ($inventory[$category] as $key => &$item) {
            if ($item['name'] === $itemName) {
                $item['quantity'] = (int)$quantity;
                saveInventory($inventory);
                echo json_encode(['message' => "Quantity updated to $quantity for $itemName"]);
                $found = true;
                break;
            }
        }
        if (!$found) {
            http_response_code(404);
            echo json_encode(['error' => 'Item not found', 'available_items' => array_column($inventory[$category], 'name')]);
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action specified']);
        break;
}
?>
