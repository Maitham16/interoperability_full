<?php
header('Content-Type: application/json');

function logRequest() {
    $logFile = '/home/alrubayem88/public_html/assignment7/logs/p3_requests_log.txt';
    $data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'],
        'query' => $_SERVER['QUERY_STRING'],
        'body' => file_get_contents('php://input'),
        'headers' => getallheaders()
    ];

    file_put_contents($logFile, json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
}

logRequest();

$progressStatus = [
    1 => ['description' => 'Order Received', 'progress' => '1'],
    2 => ['description' => 'Materials Prepared', 'progress' => '2'],
    3 => ['description' => 'Production Started', 'progress' => '3'],
    4 => ['description' => 'First Stage Complete', 'progress' => '4'],
    5 => ['description' => 'Quality Check In Progress', 'progress' => '5'],
    6 => ['description' => 'Quality Approved', 'progress' => '6'],
    7 => ['description' => 'Final Assembly', 'progress' => '7'],
    8 => ['description' => 'Final Quality Check', 'progress' => '8'],
    9 => ['description' => 'Packaging', 'progress' => '9'],
    10 => ['description' => 'Ready for Shipment', 'progress' => '10']
];

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id < 1 || $id > 10) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid ID.']);
    exit;
}

if (array_key_exists($id, $progressStatus)) {
    echo json_encode($progressStatus[$id], JSON_PRETTY_PRINT);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Progress information not found.']);
}