<?php
header("Content-Type: text/plain");

function logRequest() {
    $logFile = '/home/alrubayem88/public_html/assignment7/logs/correlator_endpoint_requests_log.txt';
    $data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'],
        'query' => $_SERVER['QUERY_STRING'],
        'body' => file_get_contents('php://input'),
        'headers' => getallheaders()
    ];

    file_put_contents($logFile, json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
}

logRequest();

$registrationUrl = 'https://endor.wst.univie.ac.at/iop-ass07/participants/12142043/correlator';  // Adjusted endpoint path

$correlatorUrl = "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/correlator.php";

$ch = curl_init($registrationUrl);

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, $correlatorUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: text/plain'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

if ($httpCode == 200) {
    echo "Endpoint successfully registered";
} else {
    echo "Failed to register endpoint. Status code: " . $httpCode;
}
?>