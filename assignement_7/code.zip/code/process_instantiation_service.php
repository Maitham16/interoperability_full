<?php
header("Content-Type: application/json");

function logRequest() {
    $logFile = '/home/alrubayem88/public_html/assignment7/logs/p4_requests_log.txt';
    $data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'],
        'query' => $_SERVER['QUERY_STRING'],
        'body' => file_get_contents('php://input'),
        'headers' => getallheaders()
    ];

    file_put_contents($logFile, json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
}

logRequest();

$instanceFile = '/home/alrubayem88/public_html/assignment7/data/process_instances.json';

function saveInstance($id, $url) {
    global $instanceFile;
    $instances = [];
    if (file_exists($instanceFile)) {
        $instances = json_decode(file_get_contents($instanceFile), true);
    }
    $instances[] = ['id' => $id, 'url' => $url];
    file_put_contents($instanceFile, json_encode($instances, JSON_PRETTY_PRINT));
}

$boundary = "abcde";
$contentType = "multipart/form-data; boundary=$boundary";

$xmlTemplate = file_get_contents('https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/Ass07.xml');

$payload = "--" . $boundary . "\r\n" .
    "Content-Disposition: form-data; name=\"behavior\"\r\n\r\n" .
    "fork_running\r\n" .
    "--" . $boundary . "\r\n" .
    "Content-Disposition: form-data; name=\"xml\"; filename=\"Ass07.xml\"\r\n" .
    "Content-Type: application/xml\r\n\r\n" .
    $xmlTemplate . "\r\n" .
    "--" . $boundary . "--\r\n";

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://cpee.org/flow/start/xml/");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Content-Type: $contentType",
    "Content-Length: " . strlen($payload)
));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);

if(curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'cURL Error: ' . curl_error($ch)]);
} else {
    $responseData = json_decode($response, true);

    if (isset($responseData['CPEE-INSTANCE']) && isset($responseData['CPEE-INSTANCE-URL'])) {

        saveInstance($responseData['CPEE-INSTANCE'], $responseData['CPEE-INSTANCE-URL']);
        echo json_encode(['success' => 'Process instance created successfully.', 'data' => $responseData]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to retrieve instance data from response', 'response' => $responseData]);
    }
}

curl_close($ch);
?>