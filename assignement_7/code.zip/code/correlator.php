<?php
header('Content-Type: application/json');

$queueFile = '/home/alrubayem88/public_html/assignment7/messages/queue.json';
$logFile = '/home/alrubayem88/public_html/assignment7/messages/correlator_log.txt';

function logRequest($message) {
    global $logFile;
    file_put_contents($logFile, date("Y-m-d H:i:s") . ": " . json_encode($message, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
}

function enqueueMessage($message) {
    global $queueFile;
    $queue = file_exists($queueFile) ? json_decode(file_get_contents($queueFile), true) : [];
    $queue[] = $message;
    file_put_contents($queueFile, json_encode($queue, JSON_PRETTY_PRINT));
}

function transformAndEnrichMessage($message, $destination) {
    // Enrich the message with a timestamp
    $message['meta']['received_at'] = date('c');
    // Transform the message structure for a specific destination
    if ($destination === 'QualityControlSystem') {
        $newMessage = [
            'quality_data' => [
                'progress_status' => $message['body']['progress'],
                'details' => $message['body']['description']
            ],
            'timestamp' => $message['meta']['received_at']
        ];
        return json_encode($newMessage);
    }
    return json_encode($message);
}

function processMessage($message) {
    global $logFile;
    $destination = isset($message['headers']['Destination']) ? $message['headers']['Destination'] : null;

    if ($destination) {
        $ch = curl_init($destination);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        $transformedMessage = transformAndEnrichMessage($message, $destination);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $transformedMessage);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'CPEE-INSTANCE: ' . $message['headers']['CPEE-INSTANCE'],
            'CPEE-INSTANCE-UUID: ' . $message['headers']['CPEE-INSTANCE-UUID']
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        file_put_contents($logFile, json_encode([
            'status' => $httpCode,
            'response' => json_decode($response, true),
            'message' => 'Message successfully forwarded to ' . $destination
        ], JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
    } else {
        enqueueMessage($message);
        file_put_contents($logFile, "No destination specified, queuing message: " . json_encode($message, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
    }
}

$requestMethod = $_SERVER['REQUEST_METHOD'];
$headers = getallheaders();
$body = file_get_contents('php://input');
$message = [
    'headers' => $headers,
    'body' => json_decode($body, true),
    'timestamp' => time()
];

logRequest($message);
$destination = $headers['Destination'] ?? null;
if ($destination) {
    processMessage($message);
} else {
    enqueueMessage($message);
}

if ($requestMethod === 'GET' && isset($_GET['action'])) {
    if ($_GET['action'] === 'get_tag') {
        echo json_encode(['status' => 'success', 'tag' => uniqid()]);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action specified']);
    }
    exit;
}

if (isset($headers['CPEE-CALLBACK']) && $headers['CPEE-CALLBACK'] === 'true') {
    header('CPEE-CALLBACK: true');
}

echo json_encode(['status' => 'success']);
exit;
?>
