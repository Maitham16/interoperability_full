<?php
header('Content-Type: application/json');

function logRequest() {
    $logFile = '/home/alrubayem88/public_html/assignment7/logs/p1_requests_log.txt';
    $data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'],
        'query' => $_SERVER['QUERY_STRING'],
        'body' => file_get_contents('php://input'),
        'headers' => getallheaders()
    ];
    file_put_contents($logFile, json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
}

logRequest();

function sendGetRequest($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function updateXmlEndpoints($order) {
    $xmlPath = '/home/alrubayem88/public_html/assignment7/Ass07.xml';
    $xml = simplexml_load_file($xmlPath);
    $namespaces = $xml->getNamespaces(true);
    $xml->registerXPathNamespace('c', $namespaces['']);

    $endpoints = $xml->xpath('//c:endpoints')[0];

    $endpoints->component1 = 'https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/warehouse_service.php?action=get_quantity&category=' . urlencode($order[0]['category']) . '&item=' . urlencode($order[0]['material_name']);
    $endpoints->component2 = 'https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/warehouse_service.php?action=get_quantity&category=' . urlencode($order[1]['category']) . '&item=' . urlencode($order[1]['material_name']);
    $endpoints->component3 = 'https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/warehouse_service.php?action=get_quantity&category=' . urlencode($order[2]['category']) . '&item=' . urlencode($order[2]['material_name']);

    $xml->asXML($xmlPath);
}

$categoriesUrl = 'https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/warehouse_service.php?action=get_categories';
$categories = sendGetRequest($categoriesUrl);

if (!is_array($categories) || count($categories) < 3) {
    http_response_code(500);
    echo json_encode(['error' => 'Not enough categories available or error fetching categories']);
    exit;
}

$selectedCategories = array_rand($categories, 3);
$order = [];

foreach ($selectedCategories as $index) {
    $category = $categories[$index];
    $materialsUrl = "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/warehouse_service.php?action=get_materials&category=$category";
    $materials = sendGetRequest($materialsUrl);

    if (!is_array($materials) || empty($materials)) {
        continue;
    }

    $material = $materials[array_rand($materials)];
    $order[] = [
        'category' => $category,
        'material_name' => $material['name']
    ];
}

updateXmlEndpoints($order);  // Call the function to update the XML

$registerUrl = 'https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/register_endpoint.php';
$postData = http_build_query([
    'studentID' => '12142043',
    'service' => 'order-generator',
    'url' => 'https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment7/customer_service.php'
]);
$context = stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => $postData
    ]
]);
file_get_contents($registerUrl, false, $context);

echo json_encode($order);
?>
