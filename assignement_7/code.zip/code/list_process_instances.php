<?php
header("Content-Type: application/json");

function logRequest() {
    $logFile = '/home/alrubayem88/public_html/assignment7/logs/p4_list_requests_log.txt';
    $data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'],
        'query' => $_SERVER['QUERY_STRING'],
        'body' => file_get_contents('php://input'),
        'headers' => getallheaders()
    ];

    file_put_contents($logFile, json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
}

logRequest();

$instanceFile = '/home/alrubayem88/public_html/assignment7/data/process_instances.json';

function loadInstances() {
    global $instanceFile;
    if (file_exists($instanceFile)) {
        $json = file_get_contents($instanceFile);
        return json_decode($json, true);
    }
    return [];
}

$instances = loadInstances();
$result = [];

foreach ($instances as $instance) {
    $result[] = [
        'id' => $instance['id'],
        'url' => "https://cpee.org/flow/?monitor=" . $instance['url']
    ];
}

echo json_encode($result, JSON_PRETTY_PRINT);
?>