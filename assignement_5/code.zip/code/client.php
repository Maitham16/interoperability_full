<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$options = [
    'soap_version' => SOAP_1_1,
    'exceptions' => true,
    'trace' => 1,
    'cache_wsdl' => WSDL_CACHE_NONE,
    'features' => SOAP_SINGLE_ELEMENT_ARRAYS,
];

$client = new SoapClient("https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment5/crud.wsdl", $options);

$output = "";

function formatSoapXML($xml)
{
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if ($dom->loadXML($xml)) {
        return htmlentities($dom->saveXML());
    } else {
        throw new Exception("Invalid XML format");
    }
}

function extractUpdateResponse($xmlString)
{
    $dom = new DOMDocument();
    $dom->loadXML($xmlString);
    $xpath = new DOMXPath($dom);
    $status = $xpath->evaluate('string(//Status)');
    $updatedXML = $xpath->evaluate('string(//UpdatedXML)');

    $updatedXML = htmlspecialchars_decode($updatedXML);
    $updatedDOM = new DOMDocument();
    $updatedDOM->loadXML($updatedXML);
    $updatedDOM->formatOutput = true;
    $formattedUpdatedXML = htmlentities($updatedDOM->saveXML());

    return "Status: $status\n\nUpdated XML:\n$formattedUpdatedXML";
}

// Update operation
$params = [
    'UserID' => '9eaaab3e-cd58-4a0e-93df-afcbb47dec30',
    'StartDate' => '2023-12-01T00:00:00',
    'Amount' => 100.80,
    'Type' => 'VISA'
];

try {
    $updateResult = $client->update($params);
    $output .= "Update Result: Success<br><br>";
    $output .= "SOAP Request:<br><pre>" . formatSoapXML($client->__getLastRequest()) . "</pre><br>";
    $output .= "SOAP Response:<br><pre>" . formatSoapXML($client->__getLastResponse()) . "</pre><br>";
    $output .= "Update Response:<br><pre>" . extractUpdateResponse($client->__getLastResponse()) . "</pre><br>";
} catch (SoapFault $e) {
    $output .= "SOAP Fault: " . $e->getMessage() . "<br><br>";
}

function extractCreateResponse($xmlString)
{
    $dom = new DOMDocument();
    $dom->loadXML($xmlString);
    $xpath = new DOMXPath($dom);
    $status = $xpath->evaluate('string(//Status)');
    $createdXML = $xpath->evaluate('string(//CreatedXML)');

    if (empty($createdXML)) {
        throw new Exception("CreatedXML is empty");
    }

    $createdXML = htmlspecialchars_decode($createdXML);
    $createdDOM = new DOMDocument();
    if (!$createdDOM->loadXML($createdXML)) {
        throw new Exception("Failed to load CreatedXML");
    }
    $createdDOM->formatOutput = true;
    $formattedCreatedXML = htmlentities($createdDOM->saveXML());

    return "Status: $status\n\nCreated XML:\n$formattedCreatedXML";
}

// Create operation
$params = [
    'Email' => 'newuser@example.com',
    'SubscriptionStartDate' => '2024-01-01T00:00:00',
    'SubscriptionEndDate' => '2025-01-01T00:00:00',
    'SubscriptionAmount' => 49.99,
    'PaymentType' => 'VISA',
    'CardNumber' => '1234567890123456',
    'ExpiryDate' => '12/30',
    'CharacterName' => 'newcharacter',
    'CharacterRealm' => 'newrealm',
    'CharacterRace' => 'newrace',
    'CharacterClass' => 'newclass',
    'CharacterStrength' => 100,
    'PrimitiveArray' => ['item1', 'item2', 'item3'],
    'ObjectArray' => [
        (object)['number' => 1, 'object' => 'sword'],
        (object)['number' => 2, 'object' => 'arrow']
    ]
];

try {
    $createResult = $client->create($params);
    $output .= "Create Result: Success<br><br>";
    $output .= "SOAP Request:<br><pre>" . formatSoapXML($client->__getLastRequest()) . "</pre><br>";
    $output .= "SOAP Response:<br><pre>" . formatSoapXML($client->__getLastResponse()) . "</pre><br>";
    $output .= "Create Response:<br><pre>" . extractCreateResponse($client->__getLastResponse()) . "</pre><br>";
} catch (SoapFault $e) {
    $output .= "SOAP Fault: " . $e->getMessage() . "<br><br>";
} catch (Exception $e) {
    $output .= "Error: " . $e->getMessage() . "<br><br>";
}

// Delete operation
$params = [
    'UserID' => '77fdbef2-3feb-450e-a229-ff019d1a321a',
    'Email' => 'michael66@example.net'
];

try {
    $deleteResult = $client->delete($params);
    $output .= "Delete Result: Success<br><br>";
    $output .= "SOAP Request:<br><pre>" . formatSoapXML($client->__getLastRequest()) . "</pre><br>";
    $output .= "SOAP Response:<br><pre>" . formatSoapXML($client->__getLastResponse()) . "</pre><br>";
    $output .= "Delete Response:<br> Status: " . $deleteResult->Status . "<br> Message: " . $deleteResult->Message . "<br>";
} catch (SoapFault $e) {
    $output .= "SOAP Fault: " . $e->getMessage() . "<br><br>";
}

function extractReadResponse($xmlString)
{
    $dom = new DOMDocument();
    $dom->loadXML($xmlString);
    $xpath = new DOMXPath($dom);
    $userXML = $xpath->evaluate('string(//UserXML)');
    $userJSON = $xpath->evaluate('string(//UserJSON)');

    $userXML = htmlspecialchars_decode($userXML);
    $userDOM = new DOMDocument();
    $userDOM->loadXML($userXML);
    $userDOM->formatOutput = true;
    $formattedUserXML = htmlentities($userDOM->saveXML());

    return "User XML:\n$formattedUserXML\n\nUser JSON:\n$userJSON";
}

// Read operation
$params = [
    'UserID' => '04003339-07d7-446f-bae3-08c48e98bfc8',
    'Email' => 'fjackson@example.org'
];

try {
    $readResult = $client->read($params);
    $output .= "Read Result: Success<br><br>";
    $output .= "SOAP Request:<br><pre>" . formatSoapXML($client->__getLastRequest()) . "</pre><br>";
    $output .= "SOAP Response:<br><pre>" . formatSoapXML($client->__getLastResponse()) . "</pre><br>";
    $output .= "Read Response:<br><pre>" . extractReadResponse($client->__getLastResponse()) . "</pre><br>";
} catch (SoapFault $e) {
    $output .= "SOAP Fault: " . $e->getMessage() . "<br><br>";
}

echo $output;
?>
