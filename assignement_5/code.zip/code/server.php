<?php
// display logs in case of error
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// reset the cache
ini_set("soap.wsdl_cache_enabled", "0");

// Update operation
function update($parameters)
{
    $UserID = $parameters->UserID;
    $StartDate = $parameters->StartDate;
    $Amount = $parameters->Amount;
    $Type = $parameters->Type;

    // Load XML Data
    $xml = new DOMDocument();
    $xml->preserveWhiteSpace = false;
    $xml->formatOutput = true;
    $xml->load('output1.xml');
    $xpath = new DOMXPath($xml);

    // Update XML
    $user = $xpath->query("/Users/User[@UserID='$UserID']")->item(0);
    if (!$user) {
        throw new SoapFault('Client', 'User not found');
    }

    $subscription = $user->getElementsByTagName('Subscription')->item(0);
    $paymentMethod = $user->getElementsByTagName('PaymentMethod')->item(0);

    if (!$subscription || !$paymentMethod) {
        throw new SoapFault('Server', 'Subscription or PaymentMethod not found for user');
    }

    $subscription->getElementsByTagName('StartDate')->item(0)->nodeValue = $StartDate;
    $subscription->getElementsByTagName('Amount')->item(0)->nodeValue = $Amount;
    $paymentMethod->getElementsByTagName('Type')->item(0)->nodeValue = $Type;

    // Save
    if ($xml->save('output1.xml')) {
        // Create response XML with only updated parts
        $updatedXml = new DOMDocument();
        $updatedXml->formatOutput = true;

        $userClone = $user->cloneNode(true);
        $updatedUser = $updatedXml->importNode($userClone, true);

        $updatedXml->appendChild($updatedUser);
        $updatedXmlString = $updatedXml->saveXML();

        $response = new stdClass();
        $response->Status = 'Success';
        $response->UpdatedXML = htmlspecialchars($updatedXmlString);

        return $response;
    } else {
        throw new SoapFault('Server', 'Failed to save updated data');
    }
}

// Create operation (I used AI to create the IDs, to make the output "pretty printed", and to make the stored XML pretty printed)
function create($parameters)
{
    // Load XML Data
    $xml = new DOMDocument();
    $xml->preserveWhiteSpace = false;
    $xml->formatOutput = true;
    $xml->load('output1.xml');
    $xpath = new DOMXPath($xml);

    // Create new User Element
    $newUser = $xml->createElement("User");
    $newUser->setAttribute("UserID", uniqid());
    $newUser->setAttribute("Email", $parameters->Email);
    $newUser->setAttribute("SubscriptionCount", "1");
    $newUser->setAttribute("PaymentMethodCount", "1");

    // Create Subscription Element
    $subscription = $xml->createElement("Subscription");
    $newUser->appendChild($subscription);
    $subscription->appendChild($xml->createElement("SubscriptionID", uniqid()));
    $subscription->appendChild($xml->createElement("StartDate", $parameters->SubscriptionStartDate));
    $subscription->appendChild($xml->createElement("EndDate", $parameters->SubscriptionEndDate));
    $subscription->appendChild($xml->createElement("Amount", $parameters->SubscriptionAmount));

    // Create PaymentMethod Element
    $paymentMethod = $xml->createElement("PaymentMethod");
    $newUser->appendChild($paymentMethod);
    $paymentMethod->appendChild($xml->createElement("PaymentMethodID", uniqid()));
    $paymentMethod->appendChild($xml->createElement("Type", $parameters->PaymentType));
    $details = $xml->createElement("Details");
    $paymentMethod->appendChild($details);
    $details->appendChild($xml->createElement("CardNumber", $parameters->CardNumber));
    $details->appendChild($xml->createElement("ExpiryDate", $parameters->ExpiryDate));

    // Create Character Element
    $character = $xml->createElement("Character");
    $newUser->appendChild($character);
    $character->appendChild($xml->createElement("CharacterID", uniqid()));
    $character->appendChild($xml->createElement("Name", $parameters->CharacterName));
    $character->appendChild($xml->createElement("Realm", $parameters->CharacterRealm));
    $character->appendChild($xml->createElement("Race", $parameters->CharacterRace));
    $character->appendChild($xml->createElement("Class", $parameters->CharacterClass));
    $character->appendChild($xml->createElement("Strength", $parameters->CharacterStrength));
    $character->appendChild($xml->createElement("Notifications"));

    // Append the new User to the Users element
    $users = $xpath->query("/Users")->item(0);
    $users->appendChild($newUser);

    // Primitive Array
    foreach ($parameters->PrimitiveArray as $primitive) {
        $primitiveElement = $xml->createElement("PrimitiveElement", $primitive);
        $newUser->appendChild($primitiveElement);
    }

    // Object Array
    foreach ($parameters->ObjectArray as $object) {
        $objectElement = $xml->createElement("ObjectElement");
        $objectElement->appendChild($xml->createElement("number", $object->number));
        $objectElement->appendChild($xml->createElement("object", $object->object));
        $newUser->appendChild($objectElement);
    }

    // Save
    if ($xml->save('output1.xml')) {
        // Create response XML
        $createdXml = new DOMDocument();
        $createdXml->formatOutput = true;

        $userClone = $newUser->cloneNode(true);
        $createdUser = $createdXml->importNode($userClone, true);

        $createdXml->appendChild($createdUser);
        $createdXmlString = $createdXml->saveXML();

        // Build response
        $response = new stdClass();
        $response->Status = 'Success';
        $response->CreatedXML = htmlspecialchars($createdXmlString);

        // Output Primitive Array and Object Array in response
        $response->OutputPrimitiveArray = $parameters->PrimitiveArray;
        $response->OutputObjectArray = $parameters->ObjectArray;

        return $response;
    } else {
        throw new SoapFault('Server', 'Failed to save created data');
    }
}

// Delete operation
function delete($parameters)
{
    $UserID = $parameters->UserID;
    $Email = $parameters->Email;

    // Load XML Data
    $xml = new DOMDocument();
    $xml->preserveWhiteSpace = false;
    $xml->formatOutput = true;
    $xml->load('output1.xml');
    $xpath = new DOMXPath($xml);

    // Find and delete the user
    $user = $xpath->query("/Users/User[@UserID='$UserID' and @Email='$Email']")->item(0);
    if (!$user) {
        throw new SoapFault('Client', 'User not found or email does not match');
    }

    $user->parentNode->removeChild($user);

    // Save
    if ($xml->save('output1.xml')) {
        $response = new stdClass();
        $response->Status = 'Success';
        $response->Message = "User $UserID deleted successfully.";
        return $response;
    } else {
        throw new SoapFault('Server', 'Failed to save updated data');
    }
}

// Read operation
function read($parameters)
{
    $UserID = $parameters->UserID;
    $Email = $parameters->Email;

    // Load XML Data
    $xml = new DOMDocument();
    $xml->preserveWhiteSpace = false;
    $xml->formatOutput = true;
    $xml->load('output1.xml');
    $xpath = new DOMXPath($xml);

    // Find user
    $user = $xpath->query("/Users/User[@UserID='$UserID' and @Email='$Email']")->item(0);
    if (!$user) {
        throw new SoapFault('Client', 'User not found or email does not match');
    }

    // Convert user to XML string
    $userXml = $user->ownerDocument->saveXML($user);

    // Convert user XML to JSON
    $userArray = json_decode(json_encode(simplexml_load_string($userXml)), true);
    $userJson = json_encode($userArray, JSON_PRETTY_PRINT);

    // Create response
    $response = new stdClass();
    $response->UserXML = htmlspecialchars($userXml);
    $response->UserJSON = $userJson;

    return $response;
}

// Create SOAP Server
$server = new SoapServer("https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment5/crud.wsdl");
$server->addFunction("update");
$server->addFunction("create");
$server->addFunction("delete");
$server->addFunction("read");
$server->handle();
?>