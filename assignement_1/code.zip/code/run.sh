#!/bin/bash

# variables database connection
DB_NAME="postgres" # my database name
DB_USER="postgres" # my username
DB_PASSWORD="postgres" # my password

# SQL and Python scripts
SQL_SCRIPT_PATH="a12142043_alrubaye.sql"
PYTHON_SCRIPT_PATH="generate_data.py"

# Create a Python virtual environment
echo "Creating Python virtual environment..."
python3 -m venv env
source env/bin/activate

# Install Python libraries
echo "Installing required Python libraries..."
pip install psycopg2-binary Faker

# Export PostgreSQL password to environment variable
export PGPASSWORD=$DB_PASSWORD

# Execute SQL script to create the database schema
echo "Creating database schema..."
psql -U $DB_USER -d $DB_NAME -f $SQL_SCRIPT_PATH

# Run the Python script to populate the database with data
echo "Populating database with data..."
python $PYTHON_SCRIPT_PATH

# Deactivate the virtual environment and cleanup
deactivate
unset PGPASSWORD

echo "Database setup and data population completed. If there is no error message above, then the operation has been done successfully"
