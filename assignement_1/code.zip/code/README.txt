- the run.sh install the missing python libraries as env
- run the script of sql schema to create the database
- populate the database with 1000 raws with fake data

to run the run.sh:

- I implemented my username, password and database name as "postgres". Please change them if you use others.
- chmod +x run.sh
- ./run.sh