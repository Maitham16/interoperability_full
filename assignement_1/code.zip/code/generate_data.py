import json
import uuid
from datetime import datetime, timedelta

import psycopg2
from faker import Faker
from psycopg2 import extras

fake = Faker()

def create_users(n):
    users = [(str(uuid.uuid4()), fake.email(), fake.date_time_between(start_date='-5y', end_date='now'), fake.random_int(min=18, max=90), fake.random_number(digits=3, fix_len=False)/100, fake.random_number(digits=3, fix_len=False)/100) for _ in range(n)]
    return users

def create_subscriptions(users):
    subscriptions = [(user[0], fake.date_time_between(start_date='-1y', end_date='now'), fake.date_time_between(start_date='now', end_date='+1y'), fake.random_number(digits=2, fix_len=False)) for user in users]
    return subscriptions

def create_payment_methods(users):
    payment_methods = [(fake.credit_card_provider(), json.dumps({
    "card_info": {
        "card_number": fake.credit_card_number(),
        "expiry_date": fake.credit_card_expire(),
        "holder_name": fake.name()
    },
    "transactions": [fake.random_number(digits=2) for _ in range(3)]
})
, user[0]) for user in users]
    return payment_methods

def create_characters(users):
    characters = [(str(uuid.uuid4()), user[0], fake.user_name(), fake.random_element(elements=('Realm1', 'Realm2', 'Realm3')), fake.random_element(elements=('Race1', 'Race2', 'Race3')), fake.random_element(elements=('Class1', 'Class2', 'Class3')), fake.random_int(min=1, max=100)) for user in users]
    return characters

def create_character_selfies(characters):
    selfies = [(character[0], fake.image_url(), fake.date_time_between(start_date='-1y', end_date='now')) for character in characters]
    return selfies

def create_notifications(n):
    notifications = [(
        fake.word(),
        f"""<notification>
                <title>{fake.sentence()}</title>
                <message>{fake.paragraph()}</message>
                <event name="{fake.word()}">
                    <date>{fake.date()}</date>
                    <details>{fake.sentence()}</details>
                </event>
            </notification>"""
    ) for _ in range(n)]
    return notifications

def create_character_notifications(characters, notifications):
    character_notifications = [(characters[i % len(characters)][0], i + 1) for i in range(len(notifications))]
    return character_notifications

def insert_data(cursor, table_name, data, columns):
    psycopg2.extras.execute_batch(cursor, f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({', '.join(['%s'] * len(columns))})", data)

def create_character_subscription_links(users, characters):
    links = []
    for character in characters:
        user_id = character[1]
        creation_date = fake.date_time_between(start_date='-1y', end_date='now')
        subscription_id_placeholder = 1
        links.append((user_id, subscription_id_placeholder, character[0], creation_date))
    return links

def main():
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='postgres', host='localhost')
    cur = conn.cursor()
    
    users = create_users(1000)
    subscriptions = create_subscriptions(users)
    payment_methods = create_payment_methods(users)
    characters = create_characters(users)
    character_selfies = create_character_selfies(characters)
    notifications = create_notifications(1000)
    character_notifications = create_character_notifications(characters, notifications)
    character_subscription_links = create_character_subscription_links(subscriptions, characters)

    insert_data(cur, 'UserAccount', users, ['UserID', 'Email', 'AccountCreationDate', 'Age', 'Height', 'Weight'])
    insert_data(cur, 'Subscription', subscriptions, ['UserID', 'SubscriptionStartDate', 'SubscriptionEndDate', 'SubscriptionAmount'])
    insert_data(cur, 'PaymentMethod', payment_methods, ['Type', 'Details', 'UserID'])
    insert_data(cur, 'Character', characters, ['CharacterID', 'UserID', 'Name', 'Realm', 'Race', 'Class', 'Strength'])
    insert_data(cur, 'CharacterSelfie', character_selfies, ['CharacterID', 'ImageURL', 'CaptureDate'])
    insert_data(cur, 'Notification', notifications, ['ExpansionName', 'Details'])
    insert_data(cur, 'CharacterNotification', character_notifications, ['CharacterID', 'NotificationID'])
    insert_data(cur, 'CharacterSubscriptionLink', character_subscription_links, ['UserID', 'SubscriptionID', 'CharacterID', 'CreationDate'])
    
    conn.commit()
    cur.close()
    conn.close()

if __name__ == "__main__":
    main()