# iop_assignment6
# Please choose another data record if you want to run it more than one time as once you run the client.php the data will be modified. As well as if you run the CURLs testing.
# I provided here some records from my xml data file:

UserID="735e190b-2985-420b-ae0e-31cfd4e382fc"
Email="mullinsreginald@example.net"
SubscriptionID= 3
PaymentMethodID= 3
CharacterID= ae930eda-c737-4649-aea1-6d69a78b9be8

UserID="04003339-07d7-446f-bae3-08c48e98bfc8"
Email="fjackson@example.org"
SubscriptionID= 5
PaymentMethodID= 5
CharacterID= fdc7dd1d-218a-4337-b5de-32bb4215f26e

UserID="b26e6e18-f3df-469a-bb0a-be9a79f0eafe"
Email="markhernandez@example.net"
SubscriptionID= 6
PaymentMethodID= 6
CharacterID>26481033-c225-43b1-9b1e-526867f8cc0b

UserID="a4d35a76-3861-4196-b7f0-4425d8b79f56"
Email="heidi10@example.org"
SubscriptionID= 7
PaymentMethodID= 7
CharacterID= d63a7c8f-5cea-4e47-a85d-68aa97036f2c
