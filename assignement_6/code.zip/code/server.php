<?php
// All error handlers implemented using AI
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ini_set("soap.wsdl_cache_enabled", "0");

$xmlFilePath = 'output1.xml';

header("Content-Type: application/xml");

$method = $_SERVER['REQUEST_METHOD'];
$input = file_get_contents('php://input');
$acceptHeader = $_SERVER['HTTP_ACCEPT'];
$userId = $_GET['UserID'] ?? '';
$email = $_GET['Email'] ?? '';
$subscriptionId = $_GET['SubscriptionID'] ?? '';
$paymentMethodId = $_GET['PaymentMethodID'] ?? '';
$characterId = $_GET['CharacterID'] ?? '';

switch ($method) {
    case 'POST':
        create($input);
        break;
    case 'GET':
        if (!empty($subscriptionId)) {
            readSubscription($userId, $subscriptionId);
        } elseif (!empty($paymentMethodId)) {
            readPaymentMethod($userId, $paymentMethodId);
        } elseif (!empty($characterId)) {
            readCharacter($userId, $characterId);
        } else {
            read($userId, $email, $acceptHeader);
        }
        break;
    case 'PUT':
        update($userId, $email, $input);
        break;
    case 'DELETE':
        delete($userId, $email);
        break;
    case 'PATCH':
        applyJsonPatchToXml($userId, $email, file_get_contents('php://input'));
        break;
    default:
        http_response_code(405);
        echo "<error>Method Not Allowed</error>";
        break;
}

function validateXmlAgainstXsd($xmlString, $xsdPath) {
    $dom = new DOMDocument();
    $dom->loadXML($xmlString);
    if (!$dom->schemaValidate($xsdPath)) {
        echo "<error>Invalid XML format according to the schema.</error>";
        return false;
    }
    return true;
}

function appendLinks($dom, $element, $userID, $email) {
    // fixed using AI
    $existingLinks = $element->getElementsByTagName('links');
    if ($existingLinks->length > 0) {
        $element->removeChild($existingLinks->item(0));
    }

    $links = $dom->createElement("links");

    $readLink = $dom->createElement("link");
    $readLink->setAttribute("rel", "self");
    $readLink->setAttribute("href", "server.php?UserID=$userID&Email=$email&method=GET");
    $links->appendChild($readLink);

    $updateLink = $dom->createElement("link");
    $updateLink->setAttribute("rel", "update");
    $updateLink->setAttribute("href", "server.php?UserID=$userID&Email=$email&method=PUT");
    $links->appendChild($updateLink);

    $deleteLink = $dom->createElement("link");
    $deleteLink->setAttribute("rel", "delete");
    $deleteLink->setAttribute("href", "server.php?UserID=$userID&Email=$email&method=DELETE");
    $links->appendChild($deleteLink);

    $subscriptionLink = $dom->createElement("link");
    $subscriptionLink->setAttribute("rel", "subscription");
    $subscriptionLink->setAttribute("href", "server.php?UserID=$userID&SubscriptionID=sub_666f677522747&method=GET");
    $links->appendChild($subscriptionLink);

    $paymentMethodLink = $dom->createElement("link");
    $paymentMethodLink->setAttribute("rel", "paymentMethod");
    $paymentMethodLink->setAttribute("href", "server.php?UserID=$userID&PaymentMethodID=pm_666f677522754&method=GET");
    $links->appendChild($paymentMethodLink);

    $characterLink = $dom->createElement("link");
    $characterLink->setAttribute("rel", "character");
    $characterLink->setAttribute("href", "server.php?UserID=$userID&CharacterID=char_666f67752275c&method=GET");
    $links->appendChild($characterLink);

    $element->appendChild($links);
}

function create($input) {
    global $xmlFilePath;
    if (!validateXmlAgainstXsd($input, 'schema.xsd')) {
        http_response_code(400);
        echo "<error>Invalid XML format according to the schema.</error>";
        return;
    }
    $xml = new SimpleXMLElement($input);
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if (!$dom->load($xmlFilePath)) {
        http_response_code(500);
        echo "<error>Failed to load XML file.</error>";
        return;
    }

    $newUser = $dom->createElement("User");
    $userID = uniqid("user_");
    $newUser->setAttribute("UserID", $userID);
    $newUser->setAttribute("Email", (string)$xml->Email);
    $newUser->setAttribute("SubscriptionCount", "1");
    $newUser->setAttribute("PaymentMethodCount", "1");

    // Handle date inputs with validation and formatting -- AI used in this snippet
    try {
        $startDate = new DateTime($xml->StartDate);
        $endDate = new DateTime($xml->EndDate);
        $formattedStartDate = $startDate->format('Y-m-d\TH:i:s');
        $formattedEndDate = $endDate->format('Y-m-d\TH:i:s');
    } catch (Exception $e) {
        http_response_code(400);
        echo "<error>Invalid date format.</error>";
        return;
    }

    $subscription = $dom->createElement("Subscription");
    $subscription->appendChild($dom->createElement("SubscriptionID", uniqid("sub_")));
    $subscription->appendChild($dom->createElement("StartDate", $formattedStartDate));
    $subscription->appendChild($dom->createElement("EndDate", $formattedEndDate));
    $subscription->appendChild($dom->createElement("Amount", floatval($xml->Amount)));
    $newUser->appendChild($subscription);

    $paymentMethod = $dom->createElement("PaymentMethod");
    $paymentMethod->appendChild($dom->createElement("PaymentMethodID", uniqid("pm_")));
    $paymentMethod->appendChild($dom->createElement("Type", (string)$xml->Type));
    $details = $dom->createElement("Details");
    $details->appendChild($dom->createElement("CardNumber", (string)$xml->CardNumber));
    $details->appendChild($dom->createElement("ExpiryDate", (string)$xml->ExpiryDate));
    $paymentMethod->appendChild($details);
    $newUser->appendChild($paymentMethod);

    $character = $dom->createElement("Character");
    $character->appendChild($dom->createElement("CharacterID", uniqid("char_")));
    $character->appendChild($dom->createElement("Name", (string)$xml->Name));
    $character->appendChild($dom->createElement("Realm", (string)$xml->Realm));
    $character->appendChild($dom->createElement("Race", (string)$xml->Race));
    $character->appendChild($dom->createElement("Class", (string)$xml->Class));
    $character->appendChild($dom->createElement("Strength", intval($xml->Strength)));
    $character->appendChild($dom->createElement("Notifications"));
    $newUser->appendChild($character);

    appendLinks($dom, $newUser, $userID, $xml->Email);

    $users = $dom->getElementsByTagName('Users')->item(0);
    if (!$users) {
        $users = $dom->createElement("Users");
        $dom->appendChild($users);
    }
    $users->appendChild($newUser);

    if ($dom->save($xmlFilePath)) {
        http_response_code(201);
        header("Content-Type: application/xml");
        echo $dom->saveXML($newUser);
    } else {
        http_response_code(500);
        echo "<error>Failed to save the user.</error>";
    }
}

function read($userId, $email, $acceptHeader) {
    global $xmlFilePath;
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if (!$dom->load($xmlFilePath)) {
        http_response_code(500);
        echo "<error>Failed to load XML file.</error>";
        return;
    }

    $xpath = new DOMXPath($dom);
    $query = "/Users/User[@UserID='$userId' and @Email='$email']";
    $users = $xpath->query($query);

    if ($users->length > 0) {
        $user = $users->item(0);
        appendLinks($dom, $user, $userId, $email);
        $userXML = $dom->saveXML($user);

        if (strpos($acceptHeader, 'application/json') !== false) {
            header('Content-Type: application/json');
            $userSimpleXML = simplexml_load_string($userXML);
            echo json_encode($userSimpleXML);
        } else {
            header('Content-Type: application/xml');
            echo $userXML;
        }
    } else {
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode(['error' => "User not found. Please check UserID and Email."]);
    }
}

function readSubscription($userId, $subscriptionId) {
    global $xmlFilePath;
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if (!$dom->load($xmlFilePath)) {
        http_response_code(500);
        echo "<error>Failed to load XML file.</error>";
        return;
    }

    $xpath = new DOMXPath($dom);
    $query = "/Users/User[@UserID='$userId']/Subscription[SubscriptionID='$subscriptionId']";
    $subscriptions = $xpath->query($query);

    if ($subscriptions->length > 0) {
        $subscription = $subscriptions->item(0);
        header('Content-Type: application/xml');
        echo $dom->saveXML($subscription);
    } else {
        http_response_code(404);
        echo json_encode(['error' => "Subscription not found. Please check UserID and SubscriptionID."]);
    }
}

function readPaymentMethod($userId, $paymentMethodId) {
    global $xmlFilePath;
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if (!$dom->load($xmlFilePath)) {
        http_response_code(500);
        echo "<error>Failed to load XML file.</error>";
        return;
    }

    $xpath = new DOMXPath($dom);
    $query = "/Users/User[@UserID='$userId']/PaymentMethod[PaymentMethodID='$paymentMethodId']";
    $paymentMethods = $xpath->query($query);

    if ($paymentMethods->length > 0) {
        $paymentMethod = $paymentMethods->item(0);
        header('Content-Type: application/xml');
        echo $dom->saveXML($paymentMethod);
    } else {
        http_response_code(404);
        echo json_encode(['error' => "Payment Method not found. Please check UserID and PaymentMethodID."]);
    }
}

function readCharacter($userId, $characterId) {
    global $xmlFilePath;
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if (!$dom->load($xmlFilePath)) {
        http_response_code(500);
        echo "<error>Failed to load XML file.</error>";
        return;
    }

    $xpath = new DOMXPath($dom);
    $query = "/Users/User[@UserID='$userId']/Character[CharacterID='$characterId']";
    $characters = $xpath->query($query);

    if ($characters->length > 0) {
        $character = $characters->item(0);
        header('Content-Type: application/xml');
        echo $dom->saveXML($character);
    } else {
        http_response_code(404);
        echo json_encode(['error' => "Character not found. Please check UserID and CharacterID."]);
    }
}

function update($userId, $email, $input) {
    global $xmlFilePath;
    if (!validateXmlAgainstXsd($input, 'schema.xsd')) {
        http_response_code(400);
        echo "<error>Invalid XML format according to the schema.</error>";
        return;
    }
    $xml = new SimpleXMLElement($input);
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;

    if (!$dom->load($xmlFilePath)) {
        http_response_code(500);
        echo "<error>Failed to load XML file.</error>";
        return;
    }

    $xpath = new DOMXPath($dom);
    $query = "/Users/User[@UserID='$userId' and @Email='$email']";
    $user = $xpath->query($query)->item(0);

    if (!$user) {
        http_response_code(404);
        echo "<error>User not found. Please check UserID and Email.</error>";
        return;
    }

    $user->setAttribute("Email", (string)$xml->Email);

    $subscription = $user->getElementsByTagName('Subscription')->item(0);
    if ($subscription) {
        $subscription->getElementsByTagName('StartDate')->item(0)->nodeValue = (string)$xml->StartDate;
        $subscription->getElementsByTagName('EndDate')->item(0)->nodeValue = (string)$xml->EndDate;
        $subscription->getElementsByTagName('Amount')->item(0)->nodeValue = (string)$xml->Amount;
    }

    $paymentMethod = $user->getElementsByTagName('PaymentMethod')->item(0);
    if ($paymentMethod) {
        $paymentMethod->getElementsByTagName('Type')->item(0)->nodeValue = (string)$xml->Type;
        $details = $paymentMethod->getElementsByTagName('Details')->item(0);
        $details->getElementsByTagName('CardNumber')->item(0)->nodeValue = (string)$xml->CardNumber;
        $details->getElementsByTagName('ExpiryDate')->item(0)->nodeValue = (string)$xml->ExpiryDate;
    }

    $character = $user->getElementsByTagName('Character')->item(0);
    if ($character) {
        $character->getElementsByTagName('Name')->item(0)->nodeValue = (string)$xml->Name;
        $character->getElementsByTagName('Realm')->item(0)->nodeValue = (string)$xml->Realm;
        $character->getElementsByTagName('Race')->item(0)->nodeValue = (string)$xml->Race;
        $character->getElementsByTagName('Class')->item(0)->nodeValue = (string)$xml->Class;
        $character->getElementsByTagName('Strength')->item(0)->nodeValue = (string)$xml->Strength;
    }

    $existingLinks = $xpath->query('/Users/User[@UserID="'.$userId.'"]/links');
    foreach ($existingLinks as $link) {
        $link->parentNode->removeChild($link);
    }
    appendLinks($dom, $user, $userId, $xml->Email);

    if ($dom->save($xmlFilePath)) {
        http_response_code(200);
        header('Content-Type: application/xml');
        echo $dom->saveXML($user);
    } else {
        http_response_code(500);
        echo "<error>Failed to update the user.</error>";
    }
}

function delete($userId, $email) {
    global $xmlFilePath;
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;

    if (!$dom->load($xmlFilePath)) {
        http_response_code(500);
        echo "<error>Failed to load XML file.</error>";
        return;
    }

    $xpath = new DOMXPath($dom);
    $query = "/Users/User[@UserID='$userId' and @Email='$email']";
    $user = $xpath->query($query)->item(0);

    if (!$user) {
        http_response_code(404);
        echo "<error>User not found. Please check UserID and Email.</error>";
        return;
    }

    $user->parentNode->removeChild($user);

    if ($dom->save($xmlFilePath)) {
        $outputDom = new DOMDocument();
        $outputDom->preserveWhiteSpace = false;
        $outputDom->formatOutput = true;
        $links = $outputDom->createElement("links");

        $listLink = $outputDom->createElement("link");
        $listLink->setAttribute("rel", "all-users");
        $listLink->setAttribute("href", "server.php?method=GET");
        $links->appendChild($listLink);

        $createLink = $outputDom->createElement("link");
        $createLink->setAttribute("rel", "create-user");
        $createLink->setAttribute("href", "server.php?method=POST");
        $links->appendChild($createLink);

        $outputDom->appendChild($links);

        http_response_code(200);
        header('Content-Type: application/xml');
        echo $outputDom->saveXML();
    } else {
        http_response_code(500);
        echo "<error>Failed to delete the user.</error>";
    }
}

// Task C
function applyJsonPatchToXml($userId, $email, $patchInput) {
    global $xmlFilePath;
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->load($xmlFilePath);

    $xpath = new DOMXPath($dom);
    $userXPath = "/Users/User[@UserID='$userId' and @Email='$email']";
    $userNode = $xpath->query($userXPath)->item(0);
    
    if (!$userNode) {
        http_response_code(404);
        echo "<error>User not found.</error>";
        return;
    }

    $patches = json_decode($patchInput, true);
    foreach ($patches as $patch) {
        $path = $patch['path'];
        $value = $patch['value'];
        
        // Convert JSON Pointer path to XPath -- AI is used here
        $xpathExpr = $userXPath . str_replace("/", "/", $path);
        $nodes = $xpath->query($xpathExpr, $userNode);

        if ($nodes->length == 0) {
            echo "<info>No nodes matched XPath: $xpathExpr</info>";
            continue;
        }

        foreach ($nodes as $node) {
            if ($patch['op'] === 'replace') {
                if ($node->nodeType == XML_ELEMENT_NODE) {
                    $node->nodeValue = $value;
                    echo "<debug>Updated $xpathExpr to $value</debug>";
                }
            }
        }
    }

    if ($dom->save($xmlFilePath)) {
        http_response_code(200);
        echo "<success>XML updated successfully.</success>";
    } else {
        http_response_code(500);
        echo "<error>Failed to update XML.</error>";
    }
}
?>
