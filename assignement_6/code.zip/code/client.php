<?php
// All error handlers implemented using AI
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function sendRequest($method, $url, $data = null, $headers = array('Content-Type: application/xml'))
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    if ($data) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    return array('response' => $response, 'httpCode' => $httpCode, 'error' => $error);
}

function formatXml($xml)
{
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if ($dom->loadXML($xml)) {
        return htmlentities($dom->saveXML());
    } else {
        throw new Exception("Invalid XML format");
    }
}

function formatJson($jsonString)
{
    return json_encode(json_decode($jsonString), JSON_PRETTY_PRINT);
}

$baseUrl = 'https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment6/server.php';

$output = "";

echo "<h2>Task A : REST</h2>";

// POST (Create)
$postData = '<?xml version="1.0" encoding="UTF-8"?>
<User>
    <Email>newuser@example.com</Email>
    <StartDate>2024-01-01T00:00:00</StartDate>
    <EndDate>2025-01-01T00:00:00</EndDate>
    <Amount>49.99</Amount>
    <Type>VISA</Type>
    <CardNumber>1234567890123456</CardNumber>
    <ExpiryDate>12/30</ExpiryDate>
    <Name>newcharacter</Name>
    <Realm>newrealm</Realm>
    <Race>newrace</Race>
    <Class>newclass</Class>
    <Strength>100</Strength>
    <PrimitiveElement>item1</PrimitiveElement>
    <PrimitiveElement>item2</PrimitiveElement>
    <PrimitiveElement>item3</PrimitiveElement>
    <ObjectElement>
        <number>1</number>
        <object>sword</object>
    </ObjectElement>
    <ObjectElement>
        <number>2</number>
        <object>arrow</object>
    </ObjectElement>
</User>';

$response = sendRequest('POST', $baseUrl, $postData);
$output .= "Post operation:\nValidation: data has been validated against schema.xsd\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";

// Extract UserID from POST response -- AI is used here
$postXml = new SimpleXMLElement($response['response']);
$userId = (string) $postXml['UserID'];
$email = (string) $postXml['Email'];

$putData = '<?xml version="1.0"?>
<User>
    <Email>updated_email@example.net</Email>
    <StartDate>2024-05-01T00:00:00</StartDate>
    <EndDate>2025-05-01T00:00:00</EndDate>
    <Amount>75.00</Amount>
    <Type>Mastercard</Type>
    <CardNumber>5555555555554444</CardNumber>
    <ExpiryDate>12/30</ExpiryDate>
    <Name>updated_character</Name>
    <Realm>updated_realm</Realm>
    <Race>updated_race</Race>
    <Class>updated_class</Class>
    <Strength>150</Strength>
    <PrimitiveElement>item1</PrimitiveElement>
    <PrimitiveElement>item2</PrimitiveElement>
    <PrimitiveElement>item3</PrimitiveElement>
    <ObjectElement>
        <number>1</number>
        <object>sword</object>
    </ObjectElement>
    <ObjectElement>
        <number>2</number>
        <object>arrow</object>
    </ObjectElement>
</User>';

$response = sendRequest('PUT', "$baseUrl?UserID=$userId&Email=$email", $putData, array('Content-Type: application/xml'));
$output .= "Put operation:\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";

// GET (Read) - XML
$response = sendRequest('GET', "$baseUrl?UserID=$userId&Email=updated_email@example.net");
$output .= "Read operation (XML):\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";

// GET (Read) - JSON
$response = sendRequest('GET', "$baseUrl?UserID=$userId&Email=updated_email@example.net", null, array('Accept: application/json'));
$output .= "Read operation (JSON):\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatJson($response['response']) . "\n\n";

// DELETE
$response = sendRequest('DELETE', "$baseUrl?UserID=$userId&Email=updated_email@example.net");
$output .= "Delete operation:\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";

echo "<pre>" . $output . "</pre>";
$output = "";

echo "<h2>Task B : HATEOAS</h2>";

// POST - self
$postData = '<?xml version="1.0" encoding="UTF-8"?>
<User>
    <Email>newuser@example.com</Email>
    <StartDate>2024-01-01T00:00:00</StartDate>
    <EndDate>2025-01-01T00:00:00</EndDate>
    <Amount>49.99</Amount>
    <Type>VISA</Type>
    <CardNumber>1234567890123456</CardNumber>
    <ExpiryDate>12/30</ExpiryDate>
    <Name>newcharacter</Name>
    <Realm>newrealm</Realm>
    <Race>newrace</Race>
    <Class>newclass</Class>
    <Strength>100</Strength>
    <PrimitiveElement>item1</PrimitiveElement>
    <PrimitiveElement>item2</PrimitiveElement>
    <PrimitiveElement>item3</PrimitiveElement>
    <ObjectElement>
        <number>1</number>
        <object>sword</object>
    </ObjectElement>
    <ObjectElement>
        <number>2</number>
        <object>arrow</object>
    </ObjectElement>
</User>';

$response = sendRequest('POST', $baseUrl, $postData);
$output .= "Post operation:\nValidation: data has been validated against schema.xsd\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";

// GET - self
$response = sendRequest('GET', "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment6/server.php?UserID=b49d0554-397b-4496-86c2-e393d78fce91&Email=tanya12@example.org");
if (!empty($response['response'])) {
    $output .= "Read operation (self - XML):\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";
} else {
    $output .= "Read operation (self - XML) returned empty response.\n";
    $output .= "Error: " . $response['error'] . "\n";
}

// GET - subscription
$response = sendRequest('GET', "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment6/server.php?UserID=b49d0554-397b-4496-86c2-e393d78fce91&SubscriptionID=1000&method=GET");
if (!empty($response['response'])) {
    $output .= "Subscription Details:\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";
} else {
    $output .= "Subscription Details operation returned empty response.\n";
    $output .= "Error: " . $response['error'] . "\n";
}

// GET - paymentMethod
$response = sendRequest('GET', "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment6/server.php?UserID=b49d0554-397b-4496-86c2-e393d78fce91&PaymentMethodID=1000&method=GET");
if (!empty($response['response'])) {
    $output .= "Payment Method Details:\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";
} else {
    $output .= "Payment Method Details operation returned empty response.\n";
    $output .= "Error: " . $response['error'] . "\n";
}

// GET - character
$response = sendRequest('GET', "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment6/server.php?UserID=b49d0554-397b-4496-86c2-e393d78fce91&CharacterID=f1264a91-3623-4465-ab20-0bc61c24bd5b&method=GET");
if (!empty($response['response'])) {
    $output .= "Character Details:\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";
} else {
    $output .= "Character Details operation returned empty response.\n";
    $output .= "Error: " . $response['error'] . "\n";
}

// PUT - self
$putData = '<?xml version="1.0" encoding="UTF-8"?>
<User>
    <Email>tanya12@example.org</Email>
    <StartDate>2024-05-01T00:00:00</StartDate>
    <EndDate>2025-05-01T00:00:00</EndDate>
    <Amount>75.00</Amount>
    <Type>Mastercard</Type>
    <CardNumber>5555555555554444</CardNumber>
    <ExpiryDate>12/30</ExpiryDate>
    <Name>updated_jamesconnie</Name>
    <Realm>updated_Realm2</Realm>
    <Race>updated_Race2</Race>
    <Class>updated_Class2</Class>
    <Strength>150</Strength>
    <PrimitiveElement>item1</PrimitiveElement>
    <PrimitiveElement>item2</PrimitiveElement>
    <PrimitiveElement>item3</PrimitiveElement>
    <ObjectElement>
        <number>1</number>
        <object>sword</object>
    </ObjectElement>
    <ObjectElement>
        <number>2</number>
        <object>shield</object>
    </ObjectElement>
</User>';

$response = sendRequest('PUT', "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment6/server.php?UserID=b49d0554-397b-4496-86c2-e393d78fce91&Email=tanya12@example.org&method=PUT", $putData);
if (!empty($response['response'])) {
    $output .= "Update operation:\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";
} else {
    $output .= "Update operation returned empty response.\n";
    $output .= "Error: " . $response['error'] . "\n";
}

// DELETE - self
$response = sendRequest('DELETE', "https://wwwlab.cs.univie.ac.at/~alrubayem88/assignment6/server.php?UserID=b49d0554-397b-4496-86c2-e393d78fce91&Email=tanya12@example.org&method=DELETE");
if (!empty($response['response'])) {
    $output .= "Delete operation:\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . formatXml($response['response']) . "\n\n";
} else {
    $output .= "Delete operation returned empty response.\n";
    $output .= "Error: " . $response['error'] . "\n";
}

echo "<pre>" . $output . "</pre>";

$output ="";

echo "<h2>Task C : RFC 6902</h2>";

// PATCH RFC 6902
$patchData = '[{"op": "replace", "path": "/PaymentMethod/Type", "value": "Mastercard by TASK C RFC 6902"}]';
$patchHeaders = array('Content-Type: application/json');  // Ensure the header is set to application/json -- AI is used here
$response = sendRequest('PATCH', $baseUrl . "?UserID=666c4b716d0b3&Email=newuser@example.com", $patchData, $patchHeaders);
$output .= "Patch operation (RFC 6902):\nResults:\nHTTP Code: " . $response['httpCode'] . "\nResponse:\n" . $response['response'] . "\n\n";

echo "<pre>" . $output . "</pre>";
?>
